#!/bin/bash
# 2022-03-25 SCH
# Iterating over Parameters Example

for parm
do
	echo $parm
done
