#!/bin/bash
# 2022-03-25 SCH
# Select Command Example

select var in alpha beta gamma
do
	echo $var
done
