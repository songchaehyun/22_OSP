#!/bin/bash
# 2022-03-25 SCH
# For loop example

for i in 7 9 2 3 4 5
do
	echo $i
done
